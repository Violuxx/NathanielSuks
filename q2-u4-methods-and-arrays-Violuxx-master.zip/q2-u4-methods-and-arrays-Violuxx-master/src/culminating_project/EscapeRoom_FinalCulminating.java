/* Name: Violet Pepper
 * Coarse: ICS 3U
 * Teacher: Mrs. McCafferey
 * Date: January 1st, 2022
 * Description: Choose your own adventure culminating project
 */

package culminating_project;

import java.util.Scanner;

public class EscapeRoom_FinalCulminating {

	public static void main(String[] args) throws InterruptedException {
		//test
		//initialize variables
		Scanner input= new Scanner(System.in);
		String game;
		boolean glassDoor = false;
		int foundNew = 0;
		int player = 0;
		int locks = 3;
		int hammerRoom = (int) Math.random()*7;
		int safeCode = ((int) ((Math.random()*9)*1000)+((int) (Math.random()*9)*100)+((int) (Math.random()*9)*100)+((int) (Math.random()*9)));
		String[] inventoryNew = new String[11];

		//room array
		String[] rooms = new String[7];
		rooms [0] = " Bedroom";
		rooms [1] = " Living Room";
		rooms [2] = " Balcony";
		rooms [3] = " Dining Room";
		rooms [4] = " Kitchen";
		rooms [5] = " Entry Hall";
		rooms [6] = " Bathroom";

		//Inventory array
		String[] inventory = new String[13];
		inventory[0] = "Gold Key";
		inventory[1] = "Code Note: "+ safeCode;
		inventory[2] = "picture";
		inventory[3] = "Wooden Box";
		inventory[4] = "Diary";
		inventory[5] = "warm steak";
		inventory[6] = "box";
		inventory[7] = "rusty key";//on
		inventory[8] = "cold steak";
		inventory[9] = "dirty key";//on
		inventory[10] = "shiny key";//on
		inventory[11] = "meat key";//on
		inventory[12] = "hammer";

		String[] objectUseBasic = new String[7];
		objectUseBasic[0] = "Behind the painting is a wall safe with a four digit code";
		objectUseBasic[1] = "enter safe code: ";
		objectUseBasic[2] = "you lift the blinds, moonlight fills the room";
		objectUseBasic[3] = "you eat the warm steak, you don�t feel hungry anymore but as you eat,\nyou bite down on something hard";
		objectUseBasic[4] = "hot water starts pouring from the shower head";
		objectUseBasic[5] = "it�s locked";
		objectUseBasic[6] = "end";

		//outputs with no affect
		String[] checkBasicOuts = new String[26];
		checkBasicOuts[0] = "It depicts a forest with a figure standing in the background";//painting
		checkBasicOuts[1] = "the woman has long golden hair and is smiling happily, there seems to be some writing on the back";//picture
		checkBasicOuts[2] = "It has the word \"sorry\" scribbled repeatedly on the back and the date \"1983\"";//writing
		checkBasicOuts[3] = "It has the word \"sorry\" scribbled repeatedly on the back and the date \"1983\"";//note
		checkBasicOuts[4] = "there�s a pot of flowers and some old magazines littered across the table";//coffee table
		checkBasicOuts[5] = "They look like marigolds, they�re starting to wilt";//flowers
		checkBasicOuts[6] = "nothing worth reading";//magazines
		checkBasicOuts[7] = "an empty black screen, the remote�s missing";//tv
		checkBasicOuts[8] = "an empty black screen, the remote�s missing";//television
		checkBasicOuts[9] = "it�s locked";//needs to have change //box
		checkBasicOuts[10] = "it�s a diary, it looks like your handwriting but you don�t remember writing it, there�s a page falling out";//book
		checkBasicOuts[11] = "It says, �I�m sorry, I wasn�t myself, I didn�t mean to do that to you, \nI�ll make sure I never do it again, even if it means being locked away forever.� \nThere is also a note �The hammer is in the " + rooms[hammerRoom]+ ",/n� the rest is illegible.";
		checkBasicOuts[12] = "a wooden table surrounded by four wooden chairs";//table
		checkBasicOuts[13] = "a wooden table surrounded by four wooden chairs";//chairs
		checkBasicOuts[14] = "They're littered with rotting food and various utensils, on top of one is a microwave";//cabinet(s)
		checkBasicOuts[15] = "They're littered with rotting food and various utensils, on top of one is a microwave";
		checkBasicOuts[16] = "it�s empty";//microwave
		checkBasicOuts[17] = "there are some pots and pans, nothing useful";
		checkBasicOuts[18] = "there are some pots and pans, nothing useful";
		checkBasicOuts[19] = "there�s water dripping from the shower head";//start add one //shower
		checkBasicOuts[20] = "a toothbrush sits carelessly on the side";//sink
		checkBasicOuts[21] = "you don�t have time for that, you need to escape";//toothbrush
		checkBasicOuts[22] = "there�s a glint of light coming from inside the toilet";//toilet
		checkBasicOuts[23] = "it looks like the exit, there are " +locks+ " padlocks holding it shut, \nwhoever put them there desperately wanted to keep something out\n�or in";
		checkBasicOuts[24] = "it�s jammed, something heavy seems to be on the other side";
		checkBasicOuts[25] = "it�s a door";

		//whether or not something has changed
		boolean[] checkAfters = new boolean[4];

		String[] checkBeforeOuts = new String[4];
		checkBeforeOuts[0] = "You don�t feel tired";//before window after key
		checkBeforeOuts[1] = "there are blinds covering it";//window
		checkBeforeOuts[2] = "Soft grey cushions lined up neatly, there is something is nestled between the cushions";//couch
		checkBeforeOuts[3] = "despite everything, it�s still you";//mirror

		String[] checkAfterOuts = new String[4];
		checkAfterOuts[0] = "There is a glint of light coming from under the bed";//bed after window
		checkAfterOuts[1] = "the window�s jammed, moonlight is pouring into the room";//window after blinds
		checkAfterOuts[2] = "soft grey cushions littered around the couch";//couch after cushion
		checkAfterOuts[3] = "There�s four numbers written, you write them down: "+ safeCode;//mirror after shower
		//end check arrays

		//title screen
		String title;

		while (true){
		System.out.println("  \"Monster's Lair\"");
		System.out.println("Play\tHelp\tExit");
			title = input.nextLine();
			if (title.equalsIgnoreCase("Exit"))
			{
				System.exit(0);
				break;
			}
			else if (title.equalsIgnoreCase("help"))
			{
				System.out.println("Monster's Lair is a text based adventure,\nto progress, use the following\n"
						+ "Commands:\n"
						+ "Enter \"room name\": to move into a nearby room\n"
						+ "Check \"object\": to recieve a description of the object\n"
						+ "Use \"item\": to use something from the world or from your inventory\n"
						+ "Inventory: shows your current inventory\n"
						+ "Look: describes the room you're in\r\n"
						+ "Help: to show command list\n");
				input.nextLine();
			}
			else if (title.equalsIgnoreCase("play"))
			{
				break;
			}
			else
			{
				System.out.println("Sorry, please enter a valid input");
			}//end if
		}//end while
		look(player);

		//game inputs
		while(true) {
			//game = input.nextLine();
			System.out.println(player);//for testing
			System.out.println(foundNew);
			while (true){
				try {
					game = input.nextLine();
					break;
				} catch (Exception e) {
					System.out.println("nothing happened");
					input.nextLine();
				} 
			}
			if (countWords(game)==1) {
				if (game.equalsIgnoreCase("inventory")) {
					Inventory(inventoryNew);
				}
				else if (game.equalsIgnoreCase("look")) {
					look(player);
				}
				else if (game.equalsIgnoreCase("help")) {
					System.out.println("Commands:\n"
							+ "Enter \"room name\": to move into a nearby room\n"
							+ "Check \"object\": to recieve a description of the object\n"
							+ "Use \"item\": to use something from the world or from your inventory\n"
							+ "Inventory: shows your current inventory\n"
							+ "Look: describes the room you're in\r\n");
					input.nextLine();
				}
			}
			else if (countWords(game) > 1){
				int i = game.indexOf(' ');
				String command = game.substring(0, i);
				String rest = game.substring(i);

				if (command.equalsIgnoreCase("use")) {
					Use(rest, inventoryNew, foundNew, inventory, locks, glassDoor, safeCode, objectUseBasic, checkAfters);
				}
				else if (command.equalsIgnoreCase("check")) {
					Check(rest, rooms, player, checkAfters, foundNew, inventory, checkBasicOuts, checkAfterOuts, checkBeforeOuts, inventoryNew);
				}
				else if (command.equalsIgnoreCase("enter")) {
					Enter(rooms, player, rest, glassDoor);
				}
				else {
					System.out.println("Nothing happened");
				}//end if
			}
			else if (locks == 0) {
				System.out.println("You run out of the apartment,\nyou have nowhere to go,\nnothing to return to...");
				Thread.sleep(3000);
				System.out.println("but you�re free...\n");
				Thread.sleep(3000);
				System.out.println("as you exit the building, the moonlight pours against you,\nand suddenly your memories come flooding back...");
				Thread.sleep(3000);
				System.out.println("you were never supposed to leave...\nyou were in there for a reason...");
				Thread.sleep(3000);
				System.out.println("as your body warps and your teach grow sharp... you begin to lose sense of humanity\nand rush off into the night.");
				Thread.sleep(3000);
				System.out.println("searching for your next victim\n");
				Thread.sleep(3000);
				System.out.println("End");
				System.exit(0);
			}
		}//end while

	}//end main

	private static void Remove(int foundNew, String[] inventoryNew) {

		inventoryNew[foundNew] = null;
	}

	private static void Found(String[] inventory, int foundNew, String[] inventoryNew) {

		inventoryNew[foundNew] = inventory[foundNew];

	}//end Found

	private static void Inventory(String[] inventoryNew) {
		int empty = 0;

		//check if inventory is empty
		for (int i= 0; i<11; i++) {
			if (inventoryNew[i] == null) {
				empty ++;
			}
		}
		if (empty == 11) {
			System.out.println("You haven't found anything yet");
		}
		//outs inventory
		else {
			for (int i= 0; i<11; i++) {
				if (inventoryNew[i] != null) {
					System.out.println("-" + inventoryNew[i]);
				}
			}//end for
		}//end if
	}//end Inventory

	private static void Use(String rest, String[] inventoryNew, int foundNew, String[] inventory, int locks, boolean glassDoor, int safeCode, String[] objectUseBasic, boolean[] checkAfters) {
		Scanner input= new Scanner(System.in);
		boolean usable = false;
		int inputUse = 0;

		//usable objects array - usable objects
		String[] objectUse = new String[13];
		objectUse[0] = (" painting");
		objectUse[1] = (" safe code");//safe code //found if correct
		objectUse[2] = (" blinds");
		objectUse[3] = (" warm steak");//after //found key
		objectUse[4] = (" shower");
		objectUse[5] = (" glass door");
		objectUse[6] = (" exit");
		objectUse[7] = (" rusty key");//on
		objectUse[8] = (" cold steak");
		objectUse[9] = (" dirty key");//on
		objectUse[10] = (" shiny key");//on
		objectUse[11] = (" meat key");//on
		objectUse[12] = (" hammer");//on

		//objects used on array - objects related to the inventory
		String[] objectUseOn = new String[6];
		objectUseOn[0] = ("box");
		objectUseOn[1] = ("microwave");
		objectUseOn[2] = ("sink");//found
		objectUseOn[3] = ("front door");
		objectUseOn[4] = ("exit");
		objectUseOn[5] = ("glass door");

		//checks if possible from uses
		for (int i= 0; i<12; i++) {
			if (rest.equalsIgnoreCase(objectUse[i])) {
				usable = true;
				inputUse = i;
			}
		}//end for

		if (usable == true) {

			//if from inventory and found, what to use it on
			if (inputUse > 6 && inventoryNew[inputUse]!=null){

				System.out.println("What do you want to use it on? ");
				String game = input.nextLine();
				input.next();

				for (int i = 0; i<6; i++) {
					//if one of the use on options
					if (game.equalsIgnoreCase(objectUseOn[i])) {
						//rusty key on box
						if (i == 0 && rest.equalsIgnoreCase("rusty key")) {
							System.out.println("inside the box is a wooden doll with blackened eyes and a small book");
							break;
						}
						//steak on microwave
						else if (i == 1 && (rest.equalsIgnoreCase("cold steak")||rest.equalsIgnoreCase("steak"))) {
							System.out.println("you heat the steak up in the microwave");
							foundNew = 5;
							Found(inventory, foundNew, inventory);
							System.out.println("You found Warm Steak");
							foundNew = 8;
							Remove(foundNew, inventoryNew);
							break;
						}
						//dirty key on sink
						else if (i == 2 && rest.equalsIgnoreCase("dirty key")) {
							System.out.println("you wash the dirty key (and your hands),\nyou found Shiny Key, \nit�s the same key but you feel slightly better");
							foundNew = 10;
							Found(inventory, foundNew, inventory);
							System.out.println("found Shiny Key");
							foundNew = 9;
							Remove(foundNew, inventoryNew);
							break;
						}
						//all exit door locks
						else if (i == 3 || i == 4) {
							if (rest.equalsIgnoreCase("dirty key")) {
								System.out.println("a sterling silver padlock falls off");
								locks = locks - 1;
								foundNew = 9; 
								Remove(foundNew, inventory);
								if (locks == 0) {
									System.out.println("The exit creaks open");
								}
							}
							else if (rest.equalsIgnoreCase("shiny key")) {
								System.out.println("a sterling silver padlock falls off");
								locks = locks - 1;
								foundNew = 10;
								Remove(foundNew, inventory);
								if (locks == 0) {
									System.out.println("The exit creaks open");
								}
							}
							else if (rest.equalsIgnoreCase("meat key")) {
								System.out.println("a red, odd smelling padlock falls off");
								locks = locks - 1;
								foundNew = 11;
								Remove(foundNew, inventory);
								if (locks == 0) {
									System.out.println("The exit creaks open");
								}
							}
							else if (rest.equalsIgnoreCase("gold key")) {
								System.out.println("a golden, ornate padlock falls off");
								locks = locks - 1;
								foundNew = 0;
								Remove(foundNew, inventory);
								if (locks == 0) {
									System.out.println("The exit creaks open");
								}
							}
						}//end key lock options

						else if (i == 5 && rest.equalsIgnoreCase("glass door")) {//balcony
							System.out.println("The glass shatters and you step onto the balcony, the cold air blows against you");
							glassDoor = true;
							foundNew = 12;
							Remove(foundNew, inventory);
						}
					}
					else {
						System.out.println("Nothing happened");
					}
				}//end inventory for
			}//end invenroy use if
			else if (inputUse > 6 && inventoryNew[inputUse]==null){//if not found yet
				System.out.println("You're missing something");
			}

			//if the object is from world
			else if (inputUse < 7) {
				if (inputUse == 0) {//painting
					System.out.println(objectUseBasic[inputUse]);
				}
				else if (inputUse == 1) {//safe code
					System.out.println(objectUseBasic[inputUse]);
					int code = input.nextInt();
					if (code == safeCode) {
						System.out.println("The safe opens");
						System.out.println("In the safe is a picture of a woman");

						if (inventoryNew[7] == null) {
							System.out.println("you found a rusty key");
							foundNew = 7;
							Found(inventory, foundNew, inventoryNew);
							foundNew = 1;
							Remove(foundNew, inventoryNew);
						}
					}
					else if (code != safeCode) {
						System.out.println("nothing happens");
					}
				}//end safe inputs
				else if (inputUse == 2) {//blinds
					System.out.println(objectUseBasic[inputUse]);
					checkAfters[0] = true;
				}
				else if (inputUse == 3 && (inventoryNew[5] != null)) {//warm steak
					System.out.println(objectUseBasic[inputUse]);
					foundNew = 11;
					Found(inventory, foundNew, inventoryNew);
					foundNew =5;
					Remove(foundNew, inventoryNew);
				}
				else if (inputUse == 4) {
					System.out.println(objectUseBasic[inputUse]);
					checkAfters[3] = true;
				}
				else if (inputUse == 5 || inputUse == 6)	{
					System.out.println(objectUseBasic[inputUse]);
				}
			}
			else {
				System.out.println("nothing happened");
			}

		}
		else {
			System.out.println("nothing happens");
		}
	}//end Use

	private static void Check(String rest, String[] rooms, int player, boolean[] checkAfters, int foundNew, String[] inventory, String[] checkBasicOuts, String[] checkAfterOuts, String[] checkBeforeOuts, String[] inventoryNew) {

		int error = 0;
		
		String[] objectsCheck = new String[34];
		objectsCheck[0] = (" painting");
		objectsCheck[1] = (" picture");
		objectsCheck[2] = (" writing");
		objectsCheck[3] = (" note");
		objectsCheck[4] = (" coffee table");
		objectsCheck[5] = (" flowers");
		objectsCheck[6] = (" magazines");
		objectsCheck[7] = (" tv");
		objectsCheck[8] = (" television");
		objectsCheck[9] = (" box");
		objectsCheck[10] = (" book");
		objectsCheck[11] = (" page");
		objectsCheck[12] = (" table");
		objectsCheck[13] = (" chairs");
		objectsCheck[14] = (" counter");
		objectsCheck[15] = (" counters");
		objectsCheck[16] = (" microwave");
		objectsCheck[17] = (" cabinet");
		objectsCheck[18] = (" cabinets");
		objectsCheck[19] = (" shower");
		objectsCheck[20] = (" sink");
		objectsCheck[21] = (" toothbrush");
		objectsCheck[22] = (" toilet");
		objectsCheck[23] = (" front door");
		objectsCheck[24] = (" laundry door");
		objectsCheck[25] = (" right door");
		objectsCheck[26] = (" under bed");//found
		objectsCheck[27] = (" cushions");//found
		objectsCheck[28] = (" fridge");//found
		objectsCheck[29] = (" inside toilet");//found
		objectsCheck[30] = (" bed"); //has two outcomes depending on a use
		objectsCheck[31] = (" window");
		objectsCheck[32] = (" couch");
		objectsCheck[33] = (" mirror");

		//checks if the input is a room
		if (rest.equalsIgnoreCase(" room")) {
			look(player);
		}
		else {
			//checks if input is a checkable object
			for (int i= 0; i<objectsCheck.length; i++) {
				if (rest.equalsIgnoreCase(objectsCheck[i])) {
					error++;
					//if object is basic
					if (i < 26) {
						System.out.println(checkBasicOuts[i]);
						break;
					}
					//if object has found command
					else if (i == 26) {	//under bed
						System.out.println("You found a gold key");
						foundNew = 0;
						Found(inventory, foundNew, inventoryNew);
					}
					else if (i == 27) {//cusions
						System.out.println("You found Wooden Box");
						foundNew = 3;
						Found(inventory, foundNew, inventoryNew);
						checkAfters[2] = true;
					}
					else if (i == 28) {//fridge
						System.out.println("It's mostly empty,\nTheres a carton of milk and half a lemon");
						if (inventoryNew[8] == null){
							System.out.println("Siting on a plate is a piece of steak.\nYou found Cold Steak");
							foundNew = 8;
							Found(inventory, foundNew, inventoryNew);
						}
					}
					else if (i == 29) {//toilet
						if (inventoryNew[9] == null && inventoryNew[10] == null) {
							System.out.println("you begrudgingly grab the shiny object,\nyou found a dirty key,\nyou feel somewhat disgusted");
							foundNew = 9;
							Found(inventory, foundNew, inventoryNew);
						}
						else {
							System.out.println("Nope.");
						}
					}
					//if object changes
					else if (i >= 30 && i <33){
						if (checkAfters[(i - 30)] == true) {
							System.out.println(checkAfterOuts[(i- 30)]);
							break;
						}
						else {
							System.out.println(checkBeforeOuts[(i- 30)]);
							break;
						}
					}//mirror code
					else if (i == 33 && checkAfters[3] == true) {
						System.out.println(checkAfterOuts[3]);
						foundNew = 1;
						Found(inventory, foundNew, inventoryNew);
					}
				}//end if
			}//end for
		}//end else
		if (error == 34) {
			System.out.println("nothing happened");
		}
	}//end Check


	private static void Enter(String[] rooms, int player, String rest, boolean glassDoor) {

		int error = 0;
		
		for (int i= 0; i<7; i++) {
			if (rest.equalsIgnoreCase(rooms[i])) {
				if (i == 2) {
					if (glassDoor == true && i < (player +2) && i > (player -2)) {
						player = i;
						look (player);
						break;
					}
					else if (i > (player +2) || i < (player -2)) {
						System.out.println("you're too far away");
						break;
					}
					else if (glassDoor == false) {
						System.out.println("The door is jammed");
					}
				}//end if
				else {
					if (i <= (player +2) && i >= (player -2)) {
						player = i;
						look(player);
						break;
					}
					else {
						System.out.println("you're too far away");
						break;
					}
				}//end else
				error++;
			}//end if
		}//end for
		if (error == 7) {
			System.out.println("invalid room input");
		}
	}// end Enter
	

	private static void look(int player) {

		//room descriptions
		String [] roomDesc = new String[7];
		roomDesc [0] = "You're in the Bedroom\nThere is a bed in the middle of the room,\n"
				+ "to the right is a window, to the left is a painting, behind you is a door";
		roomDesc [1] = "You're in the Living Room\nThere is a couch and coffee table in the middle of the room facing a tv,\n"
				+ "to the left is a balcony with glass doors, to the right is the dining room, behind you is a door to the bedroom";
		roomDesc [2] = "You're on the Balcony\n\tglass is litered around you, it�s dark out\nthere's a sweet, seemingly familiar smell in the air";
		roomDesc [3] = "You're in the Dining Room\nA neat set of a table and chairs is in the middle of the room\n"
				+ "To the left is the living room, behind you is the kitchen, to your right is a door";
		roomDesc [4] = "You're in the Kitchen\nYour surrounded by cabinets and countertops,to your left is a fridge\n"
				+ "Behind you is an archway to the dining room";
		roomDesc [5] = "You're in the Entry Hall\nA spacious room with many doors\n"
				+ "To your left is a door labeled �Laundry,� in front of you is the front door (exit), to your right is a door";
		roomDesc [6] = "You're in the Bathroom\nThere�s a toilet, shower, and sink. Above the sink is a mirror\n"
				+ "Behind you is a door to the entry hall";

		System.out.println(roomDesc[player]);
	}//end look

	private static int countWords(String game) {
		//seperates and counts words in the game string
		if(game == null){
			return 0;  
		}
		game = game.trim();
		return game.split("\\s+").length;
	}//end countWords
}//end class