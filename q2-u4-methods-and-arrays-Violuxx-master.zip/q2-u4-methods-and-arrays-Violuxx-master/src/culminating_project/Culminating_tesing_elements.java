package culminating_project;

import java.util.Scanner;

public class Culminating_tesing_elements {

	public static void main(String[] args) {

		Scanner input= new Scanner(System.in);
		String title;

		System.out.println("  \"Monster's Lair\"");
		System.out.println("Play\tHelp\tExit");
		while (true){
			title = input.nextLine();
			if (title.equalsIgnoreCase("Exit"))
			{
				System.exit(0);
				break;
			}
			else if (title.equalsIgnoreCase("help"))
			{
				System.out.println("Commands:\n"
						+ "Enter \"room name\"\n"
						+ "Check \"object\"\n"
						+ "Use \"item\"\n"
						+ "Inventory \n"
						+ "Look \r\n");
			}
			else if (title.equalsIgnoreCase("play"))
			{
				break;
			}
			else
			{
				System.out.println("Sorry, please enter a valid input");
			}//end if
		}//end while
	}

}
