/* Name: Violet Pepper
 * Coarse: ICS 3U
 * Teacher: Mrs. McCafferey
 * Date: Dec. 17, 2021
 * Description: Create a program to simulate a retail checkout. 
 */

package methods;

import java.util.Scanner;
import java.util.stream.DoubleStream;

public class A_retail_rewrite {

	public static void main(String[] args) {

		//inititalizes variables
		Scanner myInput = new Scanner(System.in);
		String itemName = null;
		String menuInput;
		int itemCount = 0;
		int amount;
		int itemCountDouble = 0;
		double cost = 0;

		//initialize arrays
		String[] cart = new String[100];
		double[] costs = new double[100];

		//set amount of items purchased
		System.out.println("How many items would you like to purchase? ");
		while (true){
			try {
				amount = myInput.nextInt();
				break;
			} catch (Exception e) {
				System.out.println("Sorry, please enter a valid amount: ");
				myInput.nextLine();
			} 
		}
		
		//initialize items
		if (amount>0) {
			for (int i=0; i< amount; i++) {
				System.out.println("Please enter the item you want to scan: ");
				itemName = myInput.nextLine();	
				while (true){
					try {
						itemName = myInput.nextLine();
						break;
					} catch (Exception e) {
						System.out.println("Sorry, please enter a valid amount");
						myInput.nextLine();
					} 
				}

				System.out.println("How many of this item are you purchasing today? ");
				while (true){
					try {
						itemCount = myInput.nextInt();
						break;
					} catch (Exception e) {
						System.out.println("Sorry, please enter a valid amount: ");
						myInput.nextLine();
					} 
				}
				System.out.print("Please enter the cost of the item: \n$");
				while (true){
					try {
						cost = myInput.nextDouble();
						break;
					} catch (Exception e) {
						System.out.print("Sorry, please enter a valid cost: \n$");
						myInput.nextLine();
					} 
				}
				itemCountDouble = itemCount;
				cost = (cost *itemCountDouble);
				costs[i]= cost;

				cart[i] = (itemName +": $"+ cost);

			} //end for
		}
		else {
			System.out.println("Have a nice day");
			System.exit(0);
		}//end if
		
		while (true){
			//display menu
			myInput.nextLine();
			System.out.println("\tAdd item\r\n"
					+ "	Remove items\r\n"
					+ "	View Cart\r\n"
					+ "	Checkout\r\n"
					+ "	Exit");
			menuInput = myInput.nextLine();

			//start menu if
			if (menuInput.equalsIgnoreCase("add item"))
			{
				amount++;
				addItems(cart, costs, itemCountDouble);
			}
			else if (menuInput.equalsIgnoreCase("remove item"))
			{
				amount--;
				removeItems(cart, amount);
			}
			else if (menuInput.equalsIgnoreCase("view cart"))
			{
				viewCart(cart, amount);	
			}
			else if (menuInput.equalsIgnoreCase("Checkout"))
			{
				System.out.println("Thank you for shopping with us today, you total is: ");
				//addapted from https://stackoverflow.com/questions/4550662/how-do-you-find-the-sum-of-all-the-numbers-in-an-array-in-java Dec. 14, 2021
				double sum = DoubleStream.of(costs).sum();
				System.out.println("$" + sum + " before tax, ");
				double tax = 0;
				checkoutTax(sum);
				System.out.println("$" +tax+ " tax");
				double newSum = 0;
				checkoutAfterTax(sum);
				System.out.println("and $" + newSum +"after tax,");

				System.exit(0);
				break;
			}
			else if (menuInput.equalsIgnoreCase("Exit"))
			{
				System.exit(0);
				break;
			}
			else
			{
				System.out.println("Sorry, please type a valid input");
			}
		}//end menu if
	}//end main

	private static double checkoutTax(double sum) {
		
		double tax;
		int sumInt = (int) (sum* 100);
		tax = ((sumInt* 0.13)/100);
		
		return tax;
	}

	private static double checkoutAfterTax(double sum) {
		
		double newSum;
		int sumInt = (int) (sum* 100);
		newSum = ((sumInt* 1.13)/100);
		
		return newSum;
	}

	private static void viewCart(String[] cart, int amount) {

		for (int i=0; i<amount; i++ ) {
			System.out.print(cart[i]+ " \n");
		}
	}

	private static String[] removeItems(String[] cart, int amount) {

		int remove;
		String[] newCart = new String[100];
		
		for(int i= 0; i<100; i++) {
		
		newCart[i]= cart[i];	
		}
		
		Scanner myInput = new Scanner(System.in);
		System.out.println("What item would you like to remove? (enter item number) ");
		remove = myInput.nextInt();
		
		newCart[remove-1] = null;

		for(int i= (remove); i<100; i++) {
			
			cart[i-1] = newCart[i];	
			}
		return cart;
	}

	private static String[] addItems(String[] cart, double[] costs, int amount) {

		Scanner myInput = new Scanner(System.in);
		int itemCount;
		double cost;
		double itemCountDouble;
		String itemName;
		
		System.out.println("Please enter the item you want to scan: ");	
		while (true){
			try {
				itemName = myInput.nextLine();
				break;
			} catch (Exception e) {
				System.out.println("Sorry, please enter a valid amount");
				myInput.nextLine();
			} 
		}

		System.out.println("How many of this item are you purchasing today? ");
		while (true){
			try {
				itemCount = myInput.nextInt();
				break;
			} catch (Exception e) {
				System.out.println("Sorry, please enter a valid amount: ");
				myInput.nextLine();
			} 
		}
		System.out.print("Please enter the cost of the item: \n$");
		while (true){
			try {
				cost = myInput.nextDouble();
				break;
			} catch (Exception e) {
				System.out.print("Sorry, please enter a valid cost: \n$");
				myInput.nextLine();
			} 
		}
		itemCountDouble = itemCount;
		cost = (cost *itemCountDouble);
		costs[amount]= cost;

		cart[amount] = (itemName +": $"+ cost);
		
		return cart;
	}

}//end class
