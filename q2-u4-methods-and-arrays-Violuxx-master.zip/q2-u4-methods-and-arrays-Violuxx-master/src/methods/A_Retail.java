/* Name: Violet Pepper
 * Coarse: ICS 3U
 * Teacher: Mrs. McCafferey
 * Date: Dec. 14, 2021
 * Description: Create a program to simulate a retail checkout. 
 */

package methods;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.DoubleStream;

public class A_Retail {

	public static void main(String[] args) {
		//https://docs.google.com/document/d/1b5hbVwlHK6gQ5ObLzcHJBRGikkKAGi4fRMZBziJKkaw/edit
		
		//inititalizes variables
		Scanner myInput = new Scanner(System.in);
		String itemName = null;
		String menuInput;
		int itemCount = 0;
		int amount;
		int itemCountDouble = 0;
		double cost = 0;

		//initialize arrays
		String[] cart = new String[100];
		double[] costs = new double[100];

		//set amount of items purchased
		System.out.println("How many items would you like to purchase? ");
		while (true){
			try {
				amount = myInput.nextInt();
				break;
			} catch (Exception e) {
				System.out.println("Sorry, please enter a valid amount: ");
				myInput.nextLine();
			} 
		}

		//initialize items
		if (amount>0) {
			for (int i=1; i<= amount; i++) {
				System.out.println("Please enter the item you want to scan: ");
				itemName = myInput.nextLine();	
				while (true){
					try {
						itemName = myInput.nextLine();
						break;
					} catch (Exception e) {
						System.out.println("Sorry, please enter a valid amount");
						myInput.nextLine();
					} 
				}

				System.out.println("How many of this item are you purchasing today? ");
				while (true){
					try {
						itemCount = myInput.nextInt();
						break;
					} catch (Exception e) {
						System.out.println("Sorry, please enter a valid amount: ");
						myInput.nextLine();
					} 
				}
				System.out.print("Please enter the cost of the item: \n$");
				while (true){
					try {
						cost = myInput.nextDouble();
						break;
					} catch (Exception e) {
						System.out.print("Sorry, please enter a valid cost: \n$");
						myInput.nextLine();
					} 
				}
				itemCountDouble = itemCount;
				cost = (cost *itemCountDouble);
				costs[i]= cost;

				cart[i] = (itemName +": $"+ cost);

			} //end for
		}
		else {
			System.out.println("Have a nice day");
			System.exit(0);
		}//end if

		while (true){
			//display menu
			myInput.nextLine();
			System.out.println("\tAdd item\r\n"
					+ "	Remove items\r\n"
					+ "	View Cart\r\n"
					+ "	Checkout\r\n"
					+ "	Exit");
			menuInput = myInput.nextLine();

			//start menu if
			if (menuInput.equalsIgnoreCase("add item"))
			{
				amount++;
				addItems(cart, costs, itemCountDouble);
			}
			else if (menuInput.equalsIgnoreCase("remove item"))
			{
				amount--;
				removeItems(cart, costs, amount);
			}
			else if (menuInput.equalsIgnoreCase("view cart"))
			{
				viewCart(cart, amount);	
			}
			else if (menuInput.equalsIgnoreCase("Checkout"))
			{
				System.out.println("Thank you for shopping with us today, you total is: ");
				//addapted from https://stackoverflow.com/questions/4550662/how-do-you-find-the-sum-of-all-the-numbers-in-an-array-in-java Dec. 14, 2021
				double sum = DoubleStream.of(costs).sum();
				System.out.println("$" + sum + " before tax, ");
				System.out.println("$" +(sum* 0.13)+ " tax");
				System.out.println("and $" +((sum* 0.13)+ sum)+" total after tax,");

				System.exit(0);
				break;
			}
			else if (menuInput.equalsIgnoreCase("Exit"))
			{
				System.exit(0);
				break;
			}
			else
			{
				System.out.println("Sorry, please type a valid input");
			}//end if
		}//end while
		
	}//end main

	private static void viewCart(String[] cart, int amount) {

		//display items in cart array
		for (int i=1; i<=amount; i++ ) {
			System.out.print(cart[i]+ " \n");
		}
	}

	private static String[] removeItems(String[] cart, double[] costs, int amount) {
		//removes item in cart array and updates costs
		
		//initializes variables
		int remove;
		String[] newCart = new String[100];

		//copys cart to new cart
		for(int i= 0; i<100; i++) {

			newCart[i]= cart[i];	
		}
		//initialize item to be removed
		Scanner myInput = new Scanner(System.in);
		System.out.println("What item would you like to remove? (enter item number) ");
		remove = myInput.nextInt();

		//update costs 
		costs[remove] = 0;

		newCart[remove] = null;

		//update cart items
		for(int i= (remove); i<100; i++) {

			cart[i] = newCart[i+1];	
		}
		return cart;
	}

	private static String[] addItems(String[] cart, double[] costs, int amount) {
		//adds item and cost to array
		
		//initializes variables
		Scanner myInput = new Scanner(System.in);
		int itemCount;
		double cost;
		double itemCountDouble;
		String itemName;

		System.out.println("Please enter the item you want to scan: ");	
		//start decisions 
		while (true){
			try {
				itemName = myInput.nextLine();
				break;
			} catch (Exception e) {
				System.out.println("Sorry, please enter a valid amount");
				myInput.nextLine();
			} 
		}

		System.out.println("How many of this item are you purchasing today? ");
		while (true){
			try {
				itemCount = myInput.nextInt();
				break;
			} catch (Exception e) {
				System.out.println("Sorry, please enter a valid amount: ");
				myInput.nextLine();
			} 
		}
		System.out.print("Please enter the cost of the item: \n$");
		while (true){
			try {
				cost = myInput.nextDouble();
				break;
			} catch (Exception e) {
				System.out.print("Sorry, please enter a valid cost: \n$");
				myInput.nextLine();
			} 
		}//end decisions
		
		//update costs
		itemCountDouble = itemCount;
		cost = (cost *itemCountDouble);
		costs[amount]= cost;
		
		//update cart
		cart[amount] = (itemName +": $"+ cost);

		return cart;
	}

}//end class
