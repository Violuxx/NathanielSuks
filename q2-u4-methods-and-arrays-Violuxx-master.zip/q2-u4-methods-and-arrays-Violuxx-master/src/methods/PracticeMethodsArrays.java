/* Name: Violet Pepper
 * Coarse: ICS 3U
 * Teacher: Mrs. McCafferey
 * Date: Dec. 13, 2021
 * Description: 
 */

package methods;

public class PracticeMethodsArrays {

	public static void main(String[] args) {

		System.out.println("Hi");
		
		//display welcome
        //loop until menu option says quit
                  //display menu (tell user what is available to select)
     
                  //collect user input (what do they want to do)
     
                  //case statement to switch between different options
                            //options in case statement call a method to execute
	}

}
