/* Name: Violet Pepper
 * Coarse: ICS 3U
 * Teacher: Mrs. McCafferey
 * Date: 
 * Description: 
 */

package arrays;

public class Practice_Arrays {

	public static void main(String[] args)
	{
		int [] scores = new int [4];

		int numPeople = 7;
		String [] names = new String[numPeople];
		names[0] = "Nicholas";
		names[1] = "Felipe";
		names[3] = "Catherine";
		names[4] = "    null";

		boolean [] keepers = {true, false, false, false, true, false};
		double [] coinValues = {2, 1.00, 0.25, 0.1, 0.05};
		char [] options = {'y', 'n', 'q'};

		//            int numOfPeople = 9;
		//            int numOfPlayers = numOfPeople;
		//            System.out.println("NumOfPeople = " + numOfPeople);
		//            System.out.println("NumOfPlayers = " + numOfPlayers);
		//            numOfPeople++;
		//            System.out.println("NumOfPeople = " + numOfPeople);
		//            System.out.println("NumOfPlayers = " + numOfPlayers);
		//            
		//            
		//            System.out.println();
		//            String [] items = {"milk", "bread", "eggs"};
		//            String [] cart = items;
		//            System.out.println("In items array");
		//            print(items);
		//            System.out.println("In cart array");
		//            print(cart);
		//            cart[0] = "cheese";
		//            System.out.println();
		//            System.out.println("In items array after change");
		//            print(items);
		//            System.out.println("In cart array after change");
		//            print(cart);
		//            
		//            
		//            //allows someone to enter values into an array and print to the screen
		//            Scanner myInput = new Scanner(System.in);
		//            System.out.println("Please enter the names of the items in your cart");
		//            for(int i = 0; i<cart.length; i++)
		//            {
		//                    cart[i] = myInput.nextLine();
		//            }//end for
		//            System.out.println("In cart array after change");
		//            print(cart);
		//            
		//            System.out.println();
		//            

		//            System.out.println(coinValues); //prints where the array is being stored in memory
		//            System.out.println(keepers[1]); //prints only the element at index 1
		//System.out.println(coinValues[3-4]); //gives an error since it calculates what's in the brackets first then tries to reference that index location

//		Arrays.print(names);
//		Arrays.print(coinValues);
//		Arrays.print(scores);
//
//
//		String [] christmasList = {"stocking", "stuffie", "chocolate"};
//		Arrays.print(christmasList);
//		christmasList = Arrays.addItem(christmasList, "tree");
//		Arrays.print(christmasList);

	}//end main

	public class Arrays
	{
		/**
		 *
		 */
		public String[] addItem(String[] array, String item)
		{
			String [] newArray = new String [array.length + 1];
			for (int i = 0; i<array.length; i++)
			{
				newArray[i] = array[i];
			}
			newArray[newArray.length-1] = item;
			return newArray;
		}

		/** Method Name: print
		 *        Description: prints an array one element per line
		 *        Parameters: boolean [] array
		 *         Returns: n/a
		 */
		public void print(boolean[] array)
		{
			for(int i = 0; i<array.length; i++)
			{
				System.out.println(array[i]);
			}//end for
		}//end print method

		/** Method Name: print
		 *        Description: prints an array one element per line
		 *        Parameters: char [] array
		 *         Returns: n/a
		 */
		public void print(char[] array)
		{
			for(int i = 0; i<array.length; i++)
			{
				System.out.println(array[i]);
			}//end for
		}//end print method

		/** Method Name: print
		 *        Description: prints an array one element per line
		 *        Parameters: double [] array
		 *         Returns: n/a
		 */
		public void print(double[] array)
		{
			for(int i = 0; i<array.length; i++)
			{
				System.out.println(array[i]);
			}//end for
		}//end print method

		/** Method Name: print
		 *        Description: prints an array one element per line
		 *        Parameters: int [] array
		 *         Returns: n/a
		 */
		public void print(int[] array)
		{
			for(int i = 0; i<array.length; i++)
			{
				System.out.println(array[i]);
			}//end for
		}//end print method

		/** Method Name: print
		 *        Description: prints an array one element per line
		 *        Parameters: String [] array
		 *         Returns: n/a
		 */
		public void print(String[] array)
		{
			for(int i = 0; i<array.length; i++)
			{
				System.out.println(array[i]);
			}//end for
		}//end print method
	}

	}//ends Arrays class