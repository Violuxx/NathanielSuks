/* Name: Violet Pepper
 * Coarse: ICS 3U
 * Teacher: Mrs. McCafferey
 * Date: Jan. 27, 2022
 * Description: base array methods
 */
package arrays;

import java.util.Scanner;

public class Arrays {

	public static void main(String[] args) {


	}//end main

	/*Method: createEmptyIntArray
	 * Desc. :
	 * 		Returns empty array of size indicated
	 * Paramaters:
	 * 		int size
	 * Return: int[] array
	 */
	private static int[] createEmptyIntArray(int size) {

		int[] array = new int[size];
		return array;
	}//end create empty int array

	/* Method: createRandomIntArray
	 * Desc. :
	 * 		Returns array of size indicated filled with random integers between min and max
	 * Paramaters: 
	 * 		int size
	 * 		int min
	 * 		int max
	 * Return: int[] array
	 */
	private static int[] createRandomIntArray(int size, int min, int max) {

		int[] array = new int[(int) (Math.random()*max) +min];
		return array;
	}//end create random int array

	/* Method: createUserDefinedArray
	 * Desc. :
	 * 		Returns array of size indicated filled with information entered by the user
	 * Paramaters:
	 * 		int size
	 * Return: int[] array
	 */
	private static int[] createUserDefinedArray(int size) {

		Scanner input= new Scanner(System.in);
		size = input.nextInt();
		int[] array = new int[size];

		return array;
	}

	/*Method: print
	 * Desc. :
	 * 		Prints each element in the array to the screen with a space between each element.
	 * Paramaters:
	 * 		int size
	 * Return: N/A	
	 */
	private static void print(int[] array) {

		System.out.println(array);
	}

	/* Method findMax
	 * Desc. :
	 * 		Returns the position of the maximum 
	 * 		value in the array.
	 * Paramaters:
	 * 		int [ ] array
	 * Return: position
	 */
	private static int findMax(int[] array) {

		java.util.Arrays.sort(array);
		return array[(array.length - 1)];
	}//emd findMax

	/* Method: find Min
	 * desc. :
	 * 		Returns the position of the minimum 
	 * 		value in the array.
	 * Paramater:
	 * 		(int [ ] array)
	 * Return: position
	 */
	private static int findMin(int[] array) {

		java.util.Arrays.sort(array);
		return array[0];
	}//emd find min

	/*Method: swap Elements
	 * Desc. :
	 * 		Swaps the values at index position1
	 * 		 with index position2.
	 * Paramaters :
	 * 		int [ ] array, 
	 * 		int position1, 
	 * 		int position2
	 * Return: N/A
	 */
	private static void swapElements(int[] array, int position1, int position2) {

		int saveInt = array[position1];
		array[position1] = array[position2];
		array[position2] = saveInt;
	}//end swap elements


	/* Method: find Element
	 * desc. :
	 * 		Returns the position of the first instance of the indicated value. 
	 * 		Returns -1 if the �value� is not found.
	 * Paramaters :
	 * 		int value, 
	 * 		int [ ] array
	 * Return: int position
	 */
	private static int findElement(int value, int[] array) {

		for (int i = 0; i<array.length; i++) {
			if (value == array[i]) {
				return i;
			}
		}
		return -1;
	}//emd find elements

	/* Method: countElements
	 * Desc. :
	 * 		Returns the number of times the �value� is found in the array.
	 * Paramaters:
	 * 		int value, 
	 * 		int [ ] array
	 * Return: int numOfElements
	 */
	private static int countElements(int value, int[] array) {

		int amount = 0;

		for (int i = 0; i<array.length; i++) {
			if (value == array[i]) {
				amount++;
			}
		}
		return amount;
	}//emd count elements

	/* Method: copy array
	 * Desc. :
	 * 		Makes a copy of the original array in another 
	 * 		location and returns the copy.
	 * Paramaters:
	 * 		int [ ] originalArray
	 * Return: int [ ] newArray
	 */
	private static int[] copyArray(int[] array) {

		int[] newArray = new int[array.length];

		for (int i = 0; i<array.length; i++) {
			newArray[i] = array[i];
		}
		return newArray;
	}//emd copy array

	/* Method: check if copy
	 * desc. :
	 * 		A copy means that there are two unique arrays that 
	 * 		contain all the same elements in the same order but
	 * 		 stored in a different location. Compares the individual 
	 * 		elements in the array and returns true if the arrays are the same.
	 * Paramaters :
	 * 		int [] array1, 
	 * 		int [] array2
	 * Return: boolean isCopy
	 */
	private static boolean checkIfCopy(int[] array1, int[] array2) {

		//initialize variables
		boolean isCopy = false;
		int count = 0;

		for (int i = 0; i<array1.length; i++) {
			if (array2[i] == array1[i]) {
				count++;
			}
		}//end for

		if (count == array1.length) {
			isCopy = true;
		}//end if count

		return isCopy;
	}//emd check if copy

	/* Method: replace element
	 * desc. :
	 * 		Replaces the element at index �position� with the indicated �value�
	 * Paramaters:
	 * 		int [ ] array, 
	 * 		int value, 
	 * 		int position
	 * Return: N/A		
	 */
	private static void replaceElement(int[] array, int value, int position) {

		array[position] = value;
	}//end replace element


	/* method: replace elements
	 * desc. :
	 * 		Replaces all elements of the original value with the new value.
	 * Paramaters:
	 * 		int [ ] array, 
	 * 		int originalValue, 
	 * 		int newValue
	 * Return: N/A	
	 */
	private static void replaceElements(int[] array, int originalValue, int newValue) {

		for (int i = 0; i<array.length; i++) {
			if (array[i] == originalValue) {
				array[i] = newValue;
			}
		}//end for
	}//end replace elements

	/* method: insert element
	 * desc. :
	 * 		Creates an array with size originalArray.length
	 * 		 +1 and inserts the element �value� 
	 * 		at index �position�. All other values >position, 
	 * 		are shifted to index+1
	 * Paramaters:
	 * 		int [ ] originalArray, 
	 * 		int value, 
	 * 		int position
	 * Return: int [ ] newArray
	 */
	private static int[] insertElement(int[] originalArray, int value, int position) {

		int[] newArray = new int[(originalArray.length +1)];
		newArray[position] = value;

		for (int i = 0; i<newArray.length; i++) {
			if (i < position) {
				newArray[i] = originalArray[i];
			}
			else if (i > position) {
				newArray[(i+1)] = originalArray[i];
			}
		}
		return newArray;
	}//end insert element

	/* Method: delete element
	 * desc. :
	 * 		Creates an array with size originalArray.length -1 
	 * 		and deletes the element at index �position�. 
	 * 		All other values >position, are shifted to index+1
	 * Paramaters:
	 * 		int [ ] originalArray, 
	 * 		int position
	 * Return: int [ ] newArray
	 */
	private static int[] deleteElement(int[] originalArray, int position) {
		
		int[] newArray = new int[(originalArray.length -1)];
		
		for (int i = 0; i<originalArray.length; i++) {
			if (i < position) {
				newArray[i] = originalArray[i];
			}
			else if (i > position) {
				newArray[i] = originalArray[(i -1)];
			}
		}
		return newArray;
	}//end delete element


	/* Method: sort high to low	
	 * desc. :
	 * 		Creates a new array where the values from the original 
	 * 		array are sorted from the Highest value to the Lowest value
	 * Paramaters: 
	 * 		int [ ] originalArray
	 * Return: int [ ] newArray
	 */
	private static int[] sortHighToLow(int[] originalArray) {
		
		int[] newArray = new int[originalArray.length];
		
		

		return newArray;
	}//end sort high to low

}//end class
